<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Mindanao State University E-library
	</title>
	<link rel="stylesheet" type="text/css" href="../dist/css/styles.css">
	<meta charset="utf-8">
	<meta name="viewport" content= "width=device-width, initial-scale=1">
</head>
<body>
	<div class="wrapper">
		<header>
			<div class="logo">
			<img src="../images/MSU_-_Gensan_logo.png">
			<h1 style="color: white; text-align: center;"><br>MINDANAO STATE UNIVERSITY</br>
	 </h1>
		</div>
			<nav>
				<ul>
					<li><a href="index.php">HOME</a></li>
					<li><a href="borrow.php">BORROWBOOK</a></li>
				</ul>
			</nav>
		</header>
		<section>
			<div class="sec_img">
			<br><br><br><br><br><br>
			<div class="box">
				<br><br><br>
				<h1 style="text-align: center; font-size: 30px; color: white;">Welcome to</h1> 
				<h1 style="text-align: center; font-size: 30px;color: white;">Mindanao State University</h1></br>
				<h1 style="text-align: center;font-size: 30px; color: white;">E-Library</h1>
			</div>
		</div>
		</section>
		<footer>
			<br>
				<p style="color: black; text-align: center;">
					Mindanao State University-General Santos City 
				</br>
					Email: campuslibrarian@msugensan.edu.ph
				</p>
			</p>
		</footer>
	</div>
</body>
</html>