<footer class="main-footer">
    <div class="container">
      <div class="pull-right hidden-xs">
        <b>All rights reserved</b>
      </div>
      <strong>Copyright &copy; 2020 <a href="https://www.facebook.com/BermzISware">Bermz ISware Solutions</a></strong>
    </div>
    <!-- /.container -->
</footer>